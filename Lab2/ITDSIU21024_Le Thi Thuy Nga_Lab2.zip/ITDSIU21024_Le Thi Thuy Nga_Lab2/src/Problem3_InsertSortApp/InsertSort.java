package Problem3_InsertSortApp;
public class InsertSort {
    private int [] arr;
    int nElems;
    int count=0;

    public InsertSort(int nElems){
        this.nElems = nElems;
        arr = new int[nElems];
    }
   public void insert(int value){
        arr[count] = value;
        count++;
    }

    public void insert_sort(){
        int in, out;
        int pass = 0;
        for (out=1; out<nElems;out++){
            int temp = arr[out];
            in = out;
            while (in>0 && arr[in-1]>= temp){
                arr[in] = arr[in-1];
                --in;
            }
            pass++;
            arr[in] = temp;
            System.out.println("The number of passing is: "+pass);
            System.out.println("The array after passing the outer loop" +out+" is: ");
            display();
            System.out.println("\n");
        }

        System.out.println("The total number of passing is: "+(nElems*(nElems-1))/4);
    }
    public void display(){
        for (int i = 0; i <= nElems-1;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
