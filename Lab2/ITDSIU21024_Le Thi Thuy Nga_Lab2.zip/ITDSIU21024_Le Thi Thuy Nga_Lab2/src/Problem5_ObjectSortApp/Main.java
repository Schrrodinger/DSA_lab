package Problem5_ObjectSortApp;

public class Main {
    public static void main(String[] args) {
        Student s = new Student();
        s.main("Evans","Patty", 24);
        s.main("Smith", "Doc", 59);
        s.main("Smith", "Lorraine", 37);
        s.main("Smith","Paul", 37);
        s.main("Yee","Tom",43);
        s.main("Hashimoto", "Sato", 21);
        s.main("Stimson", "Henry", 29);
        s.main("Velasquez", "Jose", 72);
        s.main("Vang", "Minh", 22);
        s.main("Creswell", "Lucinda", 18);
        System.out.println("List of people and their marks:\n");
        s.display();
        System.out.println("\n");
        System.out.println("Find people by firstname: ");
        s.Sortfirstname("Smith" );
        s.Sortfirstname("Jennifer" );
        System.out.println("\n");
        System.out.println("Find people by lastname: ");
        s.Sortlastname("Henry");
        s.Sortlastname("Johnson");
        System.out.println("\n");
        System.out.println("Find people by grade: ");
        s.Sortgrade(37);
        s.Sortgrade(100);

    }
}
