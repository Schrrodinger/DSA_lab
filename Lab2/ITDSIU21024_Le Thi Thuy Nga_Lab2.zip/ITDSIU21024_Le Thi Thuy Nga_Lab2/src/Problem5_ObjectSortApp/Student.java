package Problem5_ObjectSortApp;

import java.util.Objects;

public class Student {
        private String firstname , lastname;
        private double grade;
        private String[] Firstname;
        private String[] Lastname;
        private int[] Grade;
        private int count = 0;

        public Student(){
            Firstname = new String[10];
            Lastname = new String[10];
            Grade = new int[10];
        }
        public void main(String firstname , String lastname,int grade){
            Firstname[count] = firstname;
            Lastname[count] = lastname;
            Grade[count] = grade;
            count++;
        }

        public void display(){
            for (int i= 0 ; i<= 9 ; i++){
                System.out.println(Firstname[i] + " " + Lastname[i] + " " + Grade[i] );
            }
        }

        public void Sortfirstname(String firstname){
            boolean found = false;
            int count = 0;
            String[] temp1 = new String[10] ;
            int []  temp2 = new int[10];
            for (int i = 0 ; i<= 9 ; i++){
                if (Objects.equals(firstname, Firstname[i])){
                    temp1[count] = Lastname[i];
                    temp2[count] = Grade[i];
                    System.out.println( firstname + " " + temp1[count] + " "+ temp2[count]);
                    count++;
                    found = true;
                }

            }
            if (!found){
                System.out.println("Cannot find this firstname: " + firstname);
            }


//        for (int i= 0 ; i<= count ; i++){
//            System.out.println(firstname + " " + temp1[count] + " "+ temp2[count]);
//        }
        }
        public void Sortlastname(String lastname) {
            boolean found = false;
            int count = 0;
            String[] temp1 = new String[10];
            int[] temp2 = new int[10];
            for (int i = 0; i <= 9; i++) {
                if (Objects.equals(lastname, Lastname[i])) {
                    temp1[count] = Firstname[i];
                    temp2[count] = Grade[i];
                    System.out.println(temp1[count] + " " + lastname + " " + temp2[count]);
                    count++;
                    found = true;
                }

            }
            if (!found){
                System.out.println("Cannot find this lastname: " + lastname);
            }
        }

        public void Sortgrade(int grade) {
            boolean found = false;
            int count = 0;
            int i;
            String[] temp1 = new String[10];
            String[] temp2 = new String[10];
            for ( i = 0; i <= 9; i++) {
                if (Objects.equals(grade, Grade[i])) {
                    temp1[count] = Firstname[i];
                    temp2[count] = Lastname[i];
                    System.out.println(temp1[count] + " " + temp2[count]);
                    count++;
                    found = true;
                }
            }
            if (!found){
                System.out.println("No one has this mark: " + grade);
            }


        }


    }


