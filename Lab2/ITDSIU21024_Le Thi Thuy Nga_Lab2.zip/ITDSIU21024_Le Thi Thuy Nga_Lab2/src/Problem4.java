import java.util.Random;
import java.util.Scanner;
public class Problem4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array: ");
        int size = sc.nextInt();


        // Create an array of integer numbers
        int[] array = new int[size];

        // Fill the array with random data
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            array[i] = random.nextInt(100000);
        }

        // Sort the array using the bubble sort algorithm
        int comparisons = 0;
        int copies = 0;
        int swaps = 0;

        for (int i = 0; i < array.length - 1; i++) {
            for (int j = 0; j < array.length - i - 1; j++) {
                comparisons++;
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swaps++;
                    copies+=3;
                }
            }
        }

        // Print the number of comparisons, copies, and swaps made
        System.out.println("Bubble sort:");
        System.out.println("Comparisons: " + comparisons);
        System.out.println("Copies: " + copies);
        System.out.println("Swaps: " + swaps);

        // Sort the array using the insertion sort algorithm
        comparisons = 0;
        copies = 0;
        swaps = 0;

        for (int i = 1; i < array.length; i++) {
            int current = array[i];
            int j = i - 1;
            while (j >= 0 && array[j] > current) {
                copies++;
                comparisons++;
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = current;
            swaps++;
            comparisons++;
        }

        // Print the number of comparisons, copies, and swaps made
        System.out.println("Insertion sort:");
        System.out.println("Comparisons: " + comparisons);
        System.out.println("Copies: " + copies);
        System.out.println("Swaps: " + swaps);

        // Sort the array using the selection sort algorithm
        comparisons = 0;
        copies = 0;
        swaps = 0;

        for (int i = 0; i < array.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < array.length; j++) {
                comparisons++;
                if (array[j] < array[minIndex]) {
                    minIndex = j;
                    copies++;
                }
            }

            int temp = array[i];
            array[i] = array[minIndex];
            array[minIndex] = temp;
            swaps++;
            copies+=1;
        }
        // Print the number of comparisons, copies, and swaps made
        System.out.println("Selection sort:");
        System.out.println("Comparisons: " + comparisons);
        System.out.println("Copies: " + copies);
        System.out.println("Swaps: " + swaps);
    }
}
