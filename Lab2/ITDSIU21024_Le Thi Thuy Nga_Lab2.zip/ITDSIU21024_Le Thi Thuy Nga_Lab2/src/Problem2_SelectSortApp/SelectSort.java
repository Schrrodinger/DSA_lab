package Problem2_SelectSortApp;

public class SelectSort {
    private int[] arr;
    private int nElems;
    private int comparison = 0;

    public SelectSort(int max){
        arr = new int[max];
        nElems = 0;
    }

    public void insert (int value){
        if (nElems < arr.length){
            arr[nElems] = value;
            nElems++;
        }
    }
    public void select_sort(){
        int out, in, min;
        for(out=0; out<nElems-1;out++){
            min = out;
            for (in = out+1; in < nElems; in++){
                comparison++;
                if (arr[in] < arr[min]){
                    min = in;
                }
            }
            if (min != out){
                swap(out, min);
            }
            trace(out); //method display after inner loop
            System.out.println("The comparison in the inner is:" + comparison);
            //comparison=0;
        }
        System.out.println("\nTotal comparison: "+comparison);
        System.out.println("Estimated complexity: "+ (nElems*(nElems-1)/2));
    }
    private void swap (int one, int two){
        int temp = arr[one];
        arr[one] = arr[two];
        arr[two] = temp;
        System.out.println("\nSwapped: "+arr[one]+" with "+arr[two]);
    }
    private void trace(int pass){
        System.out.println("Array after pass "+(pass+1)+ ": ");
        for(int i = 0; i<nElems;i++){
            System.out.println(arr[i]+" ");
        }
        System.out.println();
    }
    public void display() {
        for (int j = 0; j < nElems; j++) { // For each element,
            System.out.print(arr[j] + " "); // Print the element followed by a space
        }
        System.out.println(""); // Print a newline character after printing all elements
    }

}
