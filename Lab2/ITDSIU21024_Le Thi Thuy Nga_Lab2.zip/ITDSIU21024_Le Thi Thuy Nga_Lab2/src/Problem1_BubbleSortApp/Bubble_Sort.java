package Problem1_BubbleSortApp;

public class Bubble_Sort {
    private int[] arr;
    private int size;
    private int count = 0;
    private int swap = 0;
    private int comparison = 0; // Total number of comparisons

    public Bubble_Sort(int size) {
        this.size = size;
        arr = new int[size];
    }

    public void Add(int value) {
        arr[count] = value;
        count++;
    }

    public void Sort() {
        for (int i = 0; i < size - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < size - 1 - i; j++) { // Adjusted loop to account for already sorted elements
                comparison++; // Increment comparison count here
                if (arr[j] > arr[j + 1]) {
                    // Swapping
                    int temp = arr[j + 1];
                    arr[j + 1] = arr[j];
                    arr[j] = temp;
                    swapped = true;
                    swap++;
                }
            }
            if (!swapped) {
                break; // Break if no swaps occurred, indicating the array is sorted
            }
            System.out.println("\nArray after outer loop " + (i + 1) + " is: ");
            display();
            System.out.println("The number of swaps after the " + (i + 1) + " inner loop is: " + swap);
            // Removed the incorrect calculation of comparison here
            System.out.println("The total number of comparisons: " + comparison);
        }
        //System.out.println("The total number of comparisons: " + comparison);
    }

    public void display() {
        for (int i = 0; i < size; i++) { // Adjusted loop condition
            System.out.print(arr[i] + " ");
        }
        System.out.println(); // Move to a new line after displaying the array
    }
}
