package Problem1_BubbleSortApp;

public class Main {

        public static void main(String[] args) {
            Bubble_Sort bubbleSort = new Bubble_Sort(10);
            bubbleSort.Add(77);
            bubbleSort.Add(99);
            bubbleSort.Add(44);
            bubbleSort.Add(55);
            bubbleSort.Add(22);
            bubbleSort.Add(88);
            bubbleSort.Add(11);
            bubbleSort.Add(00);
            bubbleSort.Add(66);
            bubbleSort.Add(33);
            bubbleSort.Sort();
        }
    }

