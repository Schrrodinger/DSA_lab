package Problem_02;
import java.util.Random;
public class Problem_02_ii_Array {
    public static void main(String[] args) {
        long[] arr = new long[100];
        int nElems = 0;
        long searchKey;
        int j;
        int randomIndex = 0;
        int AppearanceCount = 0;
        boolean Found = false;
        int Comparisions = 1;
        int NumbofElmentmove = 0;
        arr[0] = 1;
        arr[1] = 15;
        arr[2] = 80;
        arr[3] = 5;
        arr[4] = 22;
        arr[5] = 13;
        nElems = 6;
        System.out.println("The initial array is: ");
        for ( j = 0 ; j<= nElems-1 ; j++){
            System.out.print(arr[j] + " ") ;
        }
        System.out.println("\nThe highest key is: " + removeMax(arr));
        nElems--;
        System.out.println("The array after remove max is: ");
        for (int i = 0; i<= nElems -1 ; i++){
            System.out.print(arr[i] + " ");
        }
        System.out.println("\n");



        Random random = new Random();
        for (int i = 0 ; i<= 99 ; i++){
            arr[i] = random.nextLong(0,99);
        }

        System.out.println("The new array with random index is: \n");
        for (int i = 0 ; i<= 99 ; i++){
            System.out.print(arr[i] + " ");
        }
        searchKey = random.nextLong(0,99);
        for ( j = 0 ; j<= 99 ; j++){
            if (arr[j] == searchKey ){
                AppearanceCount++;
                System.out.println("\nFound " + searchKey + " at index " + j);
                randomIndex =j;
                Found = true;
                break;
            }
            else {
                Comparisions++;
            }
        }
        if (j == 100){
            Found = false;
            System.out.println("\nCannot find: " + searchKey);
            nElems = 100;
            Comparisions = 0;
        }
        else{
            nElems = 100 -  AppearanceCount;
        }


        for (int i = randomIndex ; i<= nElems-1 ; i++){
            if(Found == true){
                arr[i] = arr[i+1];
                NumbofElmentmove++;
            }

        }

        System.out.println("The array after delete a random item is: ");
        for (int i = 0 ; i<= nElems -1  ; i++ ){
            System.out.print(arr[i] + " ");
        }
        System.out.println("\nThe number of memory moves to delete an item is : " + NumbofElmentmove);




        searchKey = random.nextInt(1 , 90);
        System.out.println("The array after is: ");
        for (int i = 0 ; i <= nElems -1 ; i++){
            System.out.print(arr[i] + " ");
        }
        Comparisions = 1;

        for ( int i = 0 ; i < nElems ; i++){
            if (arr[i] == searchKey ){
                System.out.println("\nFound " + searchKey + " at index " + i);
                randomIndex =i;
                Found = true;
                break;
            }
            else if (i == nElems-1){
                Comparisions = 0;
            }
            else {
                Comparisions++;
            }

        }

        System.out.println("\nThe number of comparisions after change the range of number is: " + Comparisions);

        System.out.println("If we change the range of the searchKey to nextInt() , the value between two difference comparisons will be difference");

    }

    public static long removeMax(long[] arr){
        long max = arr[0];
        int Maxindex = 0;
        for (int j = 0 ; j<= arr.length-1 ; j++){
            if (max < arr[j]){
                max = arr[j];
                Maxindex = j;
            }
        }
        for (int j = Maxindex ; j <= arr.length -2 ; j++){
            arr[j] = arr[j+1];
        }
        return max;
    }

}
