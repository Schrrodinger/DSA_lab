package Problem_02.Problem_02_i;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

public class Problem_02_LowArray {
    public Problem_02_LowArray() {
    }

    public static void main(String[] args) {
        int[] lowArray = new int[5];

        int i;
        for(i = 0; i < lowArray.length; ++i) {
            lowArray[i] = i * i;
        }

        for(i = 0; i < lowArray.length; ++i) {
            System.out.println("Low array element index" + i + ":" + lowArray[i]);
        }

    }
}
