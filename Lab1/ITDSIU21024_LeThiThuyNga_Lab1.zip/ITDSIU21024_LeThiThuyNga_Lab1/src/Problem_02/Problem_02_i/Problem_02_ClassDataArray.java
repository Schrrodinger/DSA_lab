package Problem_02.Problem_02_i;

public class Problem_02_ClassDataArray {

    static class Person {
        private String name;
        private int age;

        public Person(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public void displayPerson() {
            System.out.println("Name: " + name + ", Age: " + age);
        }
    }

    public static class ClassDataArray {
        public static void main(String[] args) {
            Person[] persons = new Person[2];
            persons[0] = new Person("John", 30);
            persons[1] = new Person("Jane", 25);

            for (Person person : persons) {
                person.displayPerson();
            }
        }
    }
}
