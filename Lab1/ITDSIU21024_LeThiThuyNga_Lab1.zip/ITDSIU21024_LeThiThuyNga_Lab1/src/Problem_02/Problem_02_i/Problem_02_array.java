package Problem_02.Problem_02_i;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

public class Problem_02_array {
    public Problem_02_array() {
    }

    public static void main(String[] args) {
        int[] array = new int[]{1, 2, 3, 4, 5};

        for(int i = 0; i < array.length; ++i) {
            System.out.println("array element index " + i + ":" + array[i]);
        }

    }
}
