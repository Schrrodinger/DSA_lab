package Problem_02.Problem_02_i;

public class Problem_02_HighArray {
    private static int[] arr;
    private static int nElems;

    public Problem_02_HighArray(int max) {
        arr = new int[max];
        nElems = 0;
    }

    public static void insert(int value) {
        arr[nElems] = value;
        nElems++;
    }

    public static void display() {
        for (int i = 0; i < nElems; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println("");
    }

    public static void main(String[] args) {
        Problem_02_HighArray highArray = new Problem_02_HighArray(5);
        Problem_02_HighArray.insert(10);
        Problem_02_HighArray.insert(70);
        Problem_02_HighArray.insert(30);
        Problem_02_HighArray.display();
    }
}
