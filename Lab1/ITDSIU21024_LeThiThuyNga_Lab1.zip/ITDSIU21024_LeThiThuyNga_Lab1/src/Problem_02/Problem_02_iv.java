package Problem_02;

public class Problem_02_iv {

    public static void main(String[] args) {
        OrdArray arr1 = new OrdArray(100); // Creating first source array
        OrdArray arr2 = new OrdArray(100); // Creating second source array

        // Inserting random numbers into arr1
        arr1.insert(11);
        arr1.insert(33);
        arr1.insert(55);

        // Inserting random numbers into arr2
        arr2.insert(22);
        arr2.insert(44);
        arr2.insert(66);

        System.out.println("First array before merge:");
        arr1.display();
        System.out.println("\nSecond array before merge:");
        arr2.display();

        // Merging arr2 into arr1
        arr1.merge(arr2);

        System.out.println("Array after merge:");
        arr1.display();
    }

    public static class OrdArray {
        private long[] arr;
        private int nElems;

        public OrdArray(int max) {
            arr = new long[max];
            nElems = 0;
        }

        public int size() {
            return nElems;
        }

        public void insert(long value) {
            int i;
            for (i = 0; i < nElems; i++) {
                if (arr[i] > value) {
                    break;
                }
            }
            for (int k = nElems; k > i; k--) {
                arr[k] = arr[k - 1];
            }
            arr[i] = value;
            nElems++;
        }

        public void merge(OrdArray a2) {
            long[] tempArray = new long[this.nElems + a2.nElems];
            int i = 0, j = 0, k = 0;

            // Merge arrays while there are elements in both
            while (i < this.nElems && j < a2.nElems) {
                if (this.arr[i] < a2.arr[j]) {
                    tempArray[k++] = this.arr[i++];
                } else {
                    tempArray[k++] = a2.arr[j++];
                }
            }

            // Copy remaining elements from the first array
            while (i < this.nElems) {
                tempArray[k++] = this.arr[i++];
            }

            // Copy remaining elements from the second array
            while (j < a2.nElems) {
                tempArray[k++] = a2.arr[j++];
            }

            // Copy merged array back to the original array
            this.arr = tempArray;
            this.nElems = k;
        }

        public void display() {
            for (int i = 0; i < nElems; i++) {
                System.out.print(arr[i] + " ");
            }
            System.out.println();
        }
    }
}
