package Problem_01;

import java.util.Arrays;

public class Problem_01_ii {
    public Problem_01_ii() {
    }

    public static double findMedian(int[] numbers) {
        Arrays.sort(numbers);
        int n = numbers.length;
        return n % 2 != 0 ? (double)numbers[n / 2] : (double)(numbers[(n - 1) / 2] + numbers[n / 2]) / 2.0;
    }

    public static void main(String[] args) {
        int[] numbers = new int[]{3, 5, 1, 4, 2};
        System.out.println("The median is: " + findMedian(numbers));
        int[] evenNumbers = new int[]{3, 5, 1, 4};
        System.out.println("The median is: " + findMedian(evenNumbers));
    }
}
