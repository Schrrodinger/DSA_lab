package Problem_01;

public class Problem_01_i {

        public Problem_01_i() {
        }

        public static void main(String[] args) {
            int[] digits = new int[]{15, 22, 1, 8};
            int number = arrayToNumber(digits);
            System.out.println("The number is: " + number);
        }

        public static int arrayToNumber(int[] digits) {
            int number = 0;

            for(int i = 0; i < digits.length; ++i) {
                int power = digits.length - 1 - i;
                number = (int)((double)number + (double)digits[i] * Math.pow(10.0, (double)power));
            }

            return number;
        }
    }

