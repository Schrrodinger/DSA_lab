package Problem_01.Problem_01_iv;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//


public class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    public double getBalance() {
        return this.balance;
    }

    public void deposit(double amount) {
        this.balance += amount;
        System.out.println("Deposit: $" + amount + ", New balance: $" + this.getBalance());
    }

    public void withdraw(double amount) {
        this.balance -= amount;
        System.out.println("Withdraw: $" + amount + ", New balance: $" + this.getBalance());
    }

    public void transfer(BankAccount other, double amount) {
        if (this.balance >= amount) {
            other.deposit(amount);
            this.withdraw(amount);
        } else {
            System.out.println("Transfer successfully");
        }

    }
}
