package Problem_01.Problem_01_iv;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//
public class BankApp {
    public BankApp() {
    }

    public static void main(String[] args) {
        BankAccount acc1 = new BankAccount(2000.0);
        acc1.deposit(1000.0);
        acc1.withdraw(560.0);
        System.out.println("Current balance: $" + acc1.getBalance());
        BankAccount acc2 = new BankAccount(0.0);
        acc1.transfer(acc2, acc1.getBalance());
        System.out.println("Account 1 balance after transfer: $" + acc1.getBalance());
        System.out.println("Account 2 balance after transfer: $" + acc2.getBalance());
    }
}

