package Problem_01;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//



import java.io.PrintStream;

public class Problem_01_iii {
    public Problem_01_iii() {
    }

    public static int minGap(int[] array, int n) {
        if (n < 2) {
            return 0;
        } else {
            int minGap = Math.abs(array[1] - array[0]);

            for(int i = 2; i < n; ++i) {
                int gap = Math.abs(array[i] - array[i - 1]);
                if (gap < minGap) {
                    minGap = gap;
                }
            }

            return minGap;
        }
    }

    public static void main(String[] args) {
        int[] array = new int[]{1, 3, 6, 8, 12, 14, 18};
        int n = array.length;
        PrintStream var10000 = System.out;
        int var10001 = minGap(array, n);
        var10000.println("The minimum gap is: " + var10001);
    }
}
